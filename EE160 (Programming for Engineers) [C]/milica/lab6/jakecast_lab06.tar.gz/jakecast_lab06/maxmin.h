/*      File : driver2.c
        By   : Jake Castillo
        login: jakecast
        team : Team Jake
        Date : 9/29/16                 */

float min(float n1, float n2);
float max(float n1, float n2);

//take users input as an interger
//this number will become the maximum and minimum because it's the only number
//take another user input
//if the number is less than the minimum number then this number will become the minimum
//if the number is greater than the maximum number than this number will become the maximum
//and the first number will become the minimum
//continue to cycle and swap numbers until user ends program
//if number is in between max and min, ignore the user input
