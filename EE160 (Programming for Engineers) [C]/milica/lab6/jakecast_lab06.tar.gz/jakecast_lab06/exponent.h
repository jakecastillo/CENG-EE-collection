//#define DEBUG
float pos_power(float base, int exponent);

//Take number as base
//Take anohter number as exponent 
//Multiply base by base
//Minus one from exponent
//Repeat the multiply and minus until exponent equals 0
