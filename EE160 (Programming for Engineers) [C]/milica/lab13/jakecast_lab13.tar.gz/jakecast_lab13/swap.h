void swap (float *x, float *y);
